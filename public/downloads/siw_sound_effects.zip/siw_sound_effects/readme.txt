自由に使えるフリー効果音です。
自作ゲームなどにご利用ください。
利用規約は特にないです。著作権表示などは不要です。

ダウンロード元ページ：https://siw.nyaw.net/soundeffect
ホームページ：https://nyaw.net
連絡先：nyawnet@gmail.com

2021/09/07